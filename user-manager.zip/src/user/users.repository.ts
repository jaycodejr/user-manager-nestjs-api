import {
  ConflictException,
  Injectable,
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';
import { DataSource, Repository } from 'typeorm';
import { User } from './users.entity';
import { CreateUserDto } from './dto/create-user.dto';
import { RoleService } from '../role/role.service';
import { UserStatus } from '../enum/user-status.enum';

@Injectable()
export class UsersRepository extends Repository<User> {
  constructor(
    dataSource: DataSource,
    private roleService: RoleService,
  ) {
    super(User, dataSource.createEntityManager());
  }

  async getUserById(id: string): Promise<User> {
    const found = await this.findOne({ where: { id } });

    if (found) {
      console.log('Data', found);
      console.log(found?.role?.name);
      return found;
    }
    throw new NotFoundException(`User with ID='${id} does not exist'`);
  }

  async getUsers(): Promise<User[]> {
    return await this.find();
  }

  async createUser(createUserDto: CreateUserDto): Promise<User> {
    const { fullname, email, password } = createUserDto;
    try {
      const role = await this.roleService.getRoleByName('Administrator'); //user should select from front end

      const user = await this.create({
        fullname,
        email,
        password,
        status: UserStatus.ACTIVE,
        role: role,
      });

      await this.save(user);

      return user;
    } catch (error) {
      if (error.number === 2627) {
        throw new ConflictException(`User email '${email}' already exist`);
      } else {
        throw new InternalServerErrorException(`Failed to create user`);
      }
    }
  }
}
