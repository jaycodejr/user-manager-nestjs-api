import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { DatabaseConfig, DatabaseConfigMssql } from '../config/database.config';

@Injectable()
export class DatabaseService {
  constructor(private configService: ConfigService) {}

  async getDatabaseConfig(): Promise<DatabaseConfig | DatabaseConfigMssql> {
    if (this.configService.get<string>('DB_TYPE') === 'mssql') {
      const config: DatabaseConfigMssql = {
        type: this.configService.get<string>('DB_TYPE'),
        host: this.configService.get<string>('DB_HOST'),
        port: this.configService.get<number>('DB_PORT'),
        database: this.configService.get<string>('DB_DATABASE'),
        username: this.configService.get<string>('DB_USERNAME'),
        password: this.configService.get<string>('DB_PASSWORD'),
        options: {
          encrypt: this.configService.get<boolean>('DB_ENCRYPT_MSSQL'),
        },
        autoLoadEntities: true,
        synchronize: true,
      };

      return config;
    } else {
      const config: DatabaseConfig = {
        type: this.configService.get<string>('DB_TYPE'),
        host: this.configService.get<string>('DB_HOST'),
        port: this.configService.get<number>('DB_PORT'),
        database: this.configService.get<string>('DB_DATABASE'),
        username: this.configService.get<string>('DB_USERNAME'),
        password: this.configService.get<string>('DB_PASSWORD'),
        autoLoadEntities: true,
        synchronize: true,
      };

      return config;
    }
  }
}
