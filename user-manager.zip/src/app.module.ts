import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UsersModule } from './user/users.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DatabaseService } from './service/database.service';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { RoleModule } from './role/role.module';
import { StaffModule } from './staff/staff.module';

@Module({
  imports: [
    StaffModule,
    UsersModule,
    RoleModule,
    ConfigModule.forRoot({
      envFilePath: '.env.dev',
      expandVariables: true,
      isGlobal: true,
    }),
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: async (config: ConfigService): Promise<any> => {
        return {
          host: config.get<string>('DB_HOST'),
          type: config.get<string>('DB_TYPE'),
          port: +config.get<number>('DB_PORT'),
          database: config.get<string>('DB_DATABASE'),
          username: config.get<string>('DB_USERNAME'),
          password: config.get<string>('DB_PASSWORD'),
          options: {
            encrypt: Boolean(config.get<boolean>('DB_ENCRYPT_MSSQL')),
          },
          autoLoadEntities: true,
          synchronize: true, //change to false in production
          extra: {
            trustServerCertificate: true,
          },
        };
      },
    }),
  ],
  controllers: [AppController],
  providers: [AppService, DatabaseService],
})
export class AppModule {}
