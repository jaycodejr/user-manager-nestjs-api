import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';
import { UserStatus } from '../enum/user-status.enum';
import { IsEnum } from 'class-validator';
//import { Role } from '../role/role.entity';

@Entity('staffs')
export class Staff {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ length: 100, nullable: false })
  fullname: string;

  @Column({ length: 100, nullable: false, unique: true })
  email: string;

  @Column({ length: 200, nullable: false })
  password: string;

  @Column()
  @IsEnum(UserStatus)
  status: UserStatus;

  //   @ManyToOne(() => Role, (role) => role.user)
  //   role: Role;
}
