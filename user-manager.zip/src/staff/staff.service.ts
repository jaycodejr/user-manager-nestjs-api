import {
  ConflictException,
  Injectable,
  InternalServerErrorException,
} from '@nestjs/common';
import { StaffRepository } from './staff.repository';
import { Staff } from './staff.entity';
import { CreateStaffDto } from './dto/create-staff.dto';
import { UserStatus } from '../enum/user-status.enum';
//import { InjectRepository } from '@nestjs/typeorm';
//import { Repository } from 'typeorm';
//import { RoleService } from '../role/role.service';

@Injectable()
export class StaffService {
  constructor(
    private staffRepo: StaffRepository,
    //private readonly roleService: RoleService,
    // @InjectRepository(User)
    // private usersRepo: Repository<User>,
  ) {}

  async createUser(createStaffDto: CreateStaffDto): Promise<Staff> {
    const { fullname, email, password } = createStaffDto;
    try {
      //const role = await this.roleService.getRoleByName('Administrator'); //user should select from front end
      //console.log(fullname);
      const userData = {
        fullname,
        email,
        password,
        status: UserStatus.ACTIVE,
      };
      console.log(userData);
      const user = await this.staffRepo.create({
        fullname,
        email,
        password,
        //status: UserStatus.ACTIVE,
        //role: role,
      });

      console.log(user);

      await this.staffRepo.save(user);

      return user;
    } catch (error) {
      console.log(error);
      if (error.number === 2627) {
        throw new ConflictException(`User email '${email}' already exist`);
      } else {
        throw new InternalServerErrorException(`Failed to create user`);
      }
    }
  }
}
