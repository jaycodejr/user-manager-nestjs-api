import { Injectable } from '@nestjs/common';
import { DataSource, Repository } from 'typeorm';
import { Staff } from './staff.entity';

@Injectable()
export class StaffRepository extends Repository<Staff> {
  constructor(dataSource: DataSource) {
    super(Staff, dataSource.createEntityManager());
  }
}
