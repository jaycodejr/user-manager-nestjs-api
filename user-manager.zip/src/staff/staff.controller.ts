import { Body, Controller, Post } from '@nestjs/common';
import { StaffService } from './staff.service';
//import { EmailValidationPipe } from '../pipe/email-validation.pipe';
import { CreateStaffDto } from './dto/create-staff.dto';
import { Staff } from './staff.entity';

@Controller('staff')
export class StaffController {
  constructor(private readonly staffService: StaffService) {}

  @Post()
  //@UsePipes(EmailValidationPipe)
  createUser(@Body() createStaffDto: CreateStaffDto): Promise<Staff> {
    return this.staffService.createUser(createStaffDto);
  }
}
