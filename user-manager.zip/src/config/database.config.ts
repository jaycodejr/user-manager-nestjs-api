export interface DatabaseConfig {
  type: string;
  host: string;
  port: number;
  database: string;
  username: string;
  password: string;
  autoLoadEntities: boolean;
  synchronize: boolean;
}

export interface DatabaseConfigMssql extends DatabaseConfig {
  options: MssqlConfigOptions;
}

interface MssqlConfigOptions {
  encrypt: boolean;
}
